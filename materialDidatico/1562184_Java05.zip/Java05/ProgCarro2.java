import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;
import java.util.Arrays;

class Carro implements Comparable {
	String placa;
	LocalDate dataModelo;
	double precoVenda;
	
	public Carro(String placa, int ano, double preco){
		this.placa = placa;
		this.precoVenda = preco;
		this.dataModelo = LocalDate.of(ano, 1, 1);
	
	}
	
	public double IPVA(){
		return precoVenda * 0.04;
	}
	
	public int idade(){
		Period intervalo = dataModelo.until(LocalDate.now());
		return intervalo.getYears();
	}
	
	public String toString(){
		String aux = "Placa: " + placa; 
		aux += "\nAno: "+dataModelo.getYear() + " - "+idade()+" anos";
		aux += "\nPreço R$: "+String.format("%.2f", precoVenda);
		aux += "\nIPVA R$: "+String.format("%.2f", IPVA())+"\n";
		return aux;
	}
	
	public int compareTo(Object obj){
		Carro outro = (Carro)obj;
		if(this.idade()<outro.idade())
			return -1;
		else if (this.idade()==outro.idade())
				return 0;
			 else
				return 1;
	}
	
}

public class ProgCarro2{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);

	int quantCarros = leitor.nextInt();
	Carro[] frota = new Carro[quantCarros];
	
	for(int i=0; i<quantCarros; i++){
		String placa = leitor.next();
		int ano = leitor.nextInt();
		double preco = leitor.nextDouble();
	
		Carro novoCarro = new Carro(placa, ano, preco);
		frota[i] = novoCarro;
	}
	
	Arrays.sort(frota);
	
	for(Carro c : frota){
		System.out.println(c.toString());
	}
	
	
	
}
}	
