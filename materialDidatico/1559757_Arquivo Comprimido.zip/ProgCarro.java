import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;

class Carro{
	String placa;
	LocalDate dataModelo;
	double precoVenda;
	
	public Carro(String placa, int ano, double preco){
		this.placa = placa;
		this.precoVenda = preco;
		this.dataModelo = LocalDate.of(ano, 1, 1);
	
	}
	
	public double IPVA(){
		return precoVenda * 0.04;
	}
	
	public int idade(){
		Period intervalo = dataModelo.until(LocalDate.now());
		return intervalo.getYears();
	}
	
	
	public String toString(){
		String aux = "Placa: " + placa; 
		aux += "\nAno: "+dataModelo.getYear() + " - "+idade()+" anos";
		aux += "\nPreço R$: "+String.format("%.2f", precoVenda);
		aux += "\nIPVA R$: "+String.format("%.2f", IPVA())+"\n";
		return aux;
	}
	
	public boolean equals(Object object){
		Carro outro = (Carro)object;
		if(outro.placa.equals(this.placa))
			return true;
		else
			return false;
		
	}
	
}

public class ProgCarro{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	
	String placa = leitor.nextLine();
	int ano = leitor.nextInt();
	double preco = leitor.nextDouble();
	
	Carro novoCarro = new Carro(placa, ano, preco);
	
	System.out.println(novoCarro.toString());
	
	
}
}	
