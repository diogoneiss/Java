import java.util.Scanner;
import java.util.Arrays;

class Calculadora{
	double n1, n2, res;
	String operacao;
	
	public void calcular(){
		switch(operacao){
			case "+": res = n1+n2;
				break;
			case "-": res = n1-n2;
				break;
			case "*": res = n1*n2;
				break;
			case "/": res = n1/n2;
				break;
			default: res=0;
				break;
		}
	}
}

public class ProgCalculadora{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	
	int quantasOperacoes = leitor.nextInt();
	Calculadora calc1 = new Calculadora();
	
	for(int i=0; i<quantasOperacoes; i++){
		calc1.n1 = Double.parseDouble(leitor.next());
		calc1.operacao = leitor.next();
		calc1.n2 = Double.parseDouble(leitor.next());
	
		calc1.calcular();
		
		System.out.printf("%f %s %f = %.2f\n", calc1.n1, calc1.operacao, calc1.n2, calc1.res);
	}
}
}	
