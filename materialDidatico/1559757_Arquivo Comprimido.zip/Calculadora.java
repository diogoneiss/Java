import java.util.Scanner;
import java.util.Arrays;

public class Calculadora{


public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	double n1, n2, res;
	String operacao;
	int quantasOperacoes = leitor.nextInt();
	
	for(int i=0; i<quantasOperacoes; i++){
		n1 = Double.parseDouble(leitor.next());
		operacao = leitor.next();
		n2 = Double.parseDouble(leitor.next());
	
		switch(operacao){
			case "+": res = n1+n2;
				break;
			case "-": res = n1-n2;
				break;
			case "*": res = n1*n2;
				break;
			case "/": res = n1/n2;
				break;
			default: res=0;
				break;
		}
		System.out.printf("%f %s %f = %.2f\n", n1, operacao, n2, res);
	}
}
}	
