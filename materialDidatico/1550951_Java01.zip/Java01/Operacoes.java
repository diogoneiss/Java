import java.util.Scanner;

public class Operacoes{

	public static void main(String [] args){
		Scanner leitor = new Scanner(System.in);
		String nome;
		double a, b;
		
		System.out.print("Qual é seu nome? ");
		nome = leitor.nextLine();
		System.out.println(nome+", digite a seguir dois números reais:");
		System.out.print("Primeiro número: ");
		a = leitor.nextDouble();
		System.out.print("Segundo número: ");
		b = leitor.nextDouble();
		System.out.println();
		System.out.println(nome+ ", a soma é "+(a+b));
	}

}
