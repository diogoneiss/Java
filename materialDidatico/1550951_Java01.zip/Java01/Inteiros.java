
public class Inteiros{

	public static void main(String [] args){
		int a, b;
		a = 5;
		b = 8;
		System.out.println("A soma é "+(a+b));
	}
}
