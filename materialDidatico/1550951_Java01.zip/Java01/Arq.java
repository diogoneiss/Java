import java.util.Scanner;

public class Arq{

	public static void main(String [] args){
		Scanner leitura = new Scanner (System.in);	
		int x = leitura.nextInt();
		System.out.println(x);
	}

}
