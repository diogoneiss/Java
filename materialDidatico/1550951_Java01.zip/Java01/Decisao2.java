import java.util.Scanner;

public class Decisao2{

	public static void main(String [] args){
		Scanner leitor = new Scanner(System.in);
		String curso;
		int anos;
		
		System.out.println("Qual é o seu curso? ");
		curso = leitor.nextLine();
		
		switch(curso){
			case "Computação": anos = 4;
					break;
			case "Engenharia": anos = 5;
					break;
			case "Jogos": anos = 3;
					break;
			default: anos=0;
					break;
		}
		if(anos>0)
			System.out.println(anos+" anos de curso");
		else
			System.out.println("Não conheço este curso");
	}

}
