import java.util.Scanner;

public class Decisao{

	public static void main(String [] args){
		Scanner leitor = new Scanner(System.in);
		double a, b;
		
		System.out.println("Digite a seguir dois números reais:");
		System.out.print("Primeiro número: ");
		a = leitor.nextDouble();
		System.out.print("Segundo número: ");
		b = leitor.nextDouble();
		
		if(a>b)
				System.out.println("O primeiro é maior.");
		else if(b>a)
				System.out.println("O segundo é maior.");
		else
				System.out.println("Os números são iguais");
		
	}

}
