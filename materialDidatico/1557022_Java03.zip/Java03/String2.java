import java.util.Scanner;
import java.util.Arrays;

public class String2{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   int qtdNomes = leitor.nextInt();
   String[] nomes = new String[qtdNomes];
   
   for(int i=0; i<qtdNomes; i++)
        nomes[i] = leitor.next();
        
   String menor = nomes[0];
   
   for(int i=1; i<qtdNomes; i++)
      if(nomes[i].compareTo(menor)<0)
         menor = nomes[i];
   
   System.out.println("Primeiro nome: "+menor);

}


}