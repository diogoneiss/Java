import java.util.Scanner;
import java.util.Arrays;

public class String4{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   
   String linha = leitor.nextLine();
   
   while(!linha.toLowerCase().equals("FIM")){
      String[] detalhes = linha.split(";");
      int matric = Integer.parseInt(detalhes[0]);
      String nome = detalhes[1];
      String curso = detalhes[2];
      
      if(curso.toLowerCase().equals("computacao"))
         System.out.printf("Aluno %s de matricula %d faz %s\n", nome, matric, curso);
   
      linha = leitor.nextLine();
   
   }
}


}