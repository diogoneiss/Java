import java.util.Scanner;
import java.util.Arrays;

public class String5{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   int qtdPalavras = leitor.nextInt();
   leitor.nextLine();
   String[] palavras = new String[qtdPalavras];
   
   for(int i=0; i<qtdPalavras; i++)
      palavras[i] = leitor.nextLine();
 
   String linha = leitor.nextLine();
    
   while(!linha.toLowerCase().equals("FIM")){
      String[] detalhes = linha.split(";");
      int qualPalavra = Integer.parseInt(detalhes[0]);
      int qualPosicao = Integer.parseInt(detalhes[1]);
      String pedaco = palavras[qualPalavra].substring(qualPosicao);
      
      System.out.println(pedaco);
   
      linha = leitor.nextLine();
   
   }
}


}