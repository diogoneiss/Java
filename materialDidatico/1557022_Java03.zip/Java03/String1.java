import java.util.Scanner;
import java.util.Arrays;

public class String1{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   
   String cor = "";
   int contVermelho = 0;
   
   do{
     cor = leitor.next();
     cor = cor.toLowerCase();
     
     if(cor.equals("vermelho")) contVermelho++;
   
   }while(!cor.equals("fim"));
   
   System.out.println("Encontrei vermelho "+contVermelho+ " vezes");

}


}