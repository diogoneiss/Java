import java.util.Scanner;
import java.util.Arrays;

public class Arrays2{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   
   String[] nomesAlunos;    
   int quantidadeAlunos = leitor.nextInt();   
   int soma=0;
   int contAtivFaltantes=0;

   nomesAlunos = new String[quantidadeAlunos];
   
   for(int i=0; i<quantidadeAlunos; i++){
      System.out.println(i);
      nomesAlunos[i] = leitor.next();
   }
     
   Arrays.sort(nomesAlunos);
   
   System.out.println("Alunos em ordem alfabética: ");
   for(String s: nomesAlunos)
      System.out.println(s);
      
   String procurado = leitor.next();

   
   int posicao = Arrays.binarySearch(nomesAlunos, procurado);
   if(posicao<0)
      System.out.println("Aluno não encontrado.");   
   else
      System.out.println("Aluno na posição "+posicao);


}


}