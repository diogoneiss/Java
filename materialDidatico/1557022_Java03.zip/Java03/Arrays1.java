import java.util.Scanner;
import java.util.Arrays;

public class Arrays1{

public static void main(String[] args){
   Scanner leitor = new Scanner(System.in);
   
   int[] notasAtividades;    //array para guardar as notas das atividades de um aluno
   int quantidadeAtividades = leitor.nextInt();   //informação vinda do arquivo de dados
   int soma=0;
   int contAtivFaltantes=0;

   notasAtividades = new int[quantidadeAtividades];
   Arrays.fill(notasAtividades, -1);
   
   int quantidadeNotas = leitor.nextInt();   //informação vinda do arquivo de dados
   
   for(int i=0; i<quantidadeNotas; i++){
      int posAtividade = leitor.nextInt();
      notasAtividades[posAtividade] = leitor.nextInt();
   }
     
   for(int nota : notasAtividades){
      if(nota==-1)
         contAtivFaltantes++;
      else
         soma+=nota;
   }
   
     System.out.println("Nota total: "+soma);
     System.out.println("O aluno deixou de entregar "+contAtivFaltantes+" atividades");

}


}