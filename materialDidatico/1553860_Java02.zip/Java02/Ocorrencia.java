import java.util.Scanner;

public class Ocorrencia{

public static void main(String[] args){
	Scanner leitor= new Scanner(System.in);
	String frase = leitor.nextLine();
	char eliminar = 'a';
	String aux="";

	int pos = frase.indexOf(eliminar);
	if(eliminar!=-1)
		System.out.println("Achei "+eliminar+" na posição "+pos);
	else
		System.out.println("Não achei "+eliminar);
}

}
