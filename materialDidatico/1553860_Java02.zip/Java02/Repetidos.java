import java.util.Scanner;

public class Repetidos{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	int quant=0;
	int repetidos=0;
		
	System.out.print("Quantos números você quer verificar? ");
	quant = leitor.nextInt();
	int numeros[] = new int[quant];
	System.out.println("Digite um total de "+quant+" números:");
	
	for(int i=0; i<numeros.length; i++){
		numeros[i] = leitor.nextInt();	
		for(int j=i-1; j>=0; j--){
			if(numeros[j]==numeros[i]){
				repetidos++;
				break;
			}
		}
	}
	
	System.out.println("Existem "+repetidos+" repetições de números");
	}

}
