import java.util.Scanner;

public class Media2{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	int quantAlunos=0;
	double notasAlunos[];
	int soma=0;
	double media;
	
	System.out.print("Quantos alunos existem? ");
	quantAlunos = leitor.nextInt();
	
	notasAlunos=new double[quantAlunos];
	System.out.println("Digite a nota para "+quantAlunos+" alunos");
	
	for(int i=0; i<quantAlunos; i++){
		notasAlunos[i] = leitor.nextDouble();
		soma+=notasAlunos[i];
	}
	
	media = soma/quantAlunos;
	
	System.out.print("As notas são: ");
	for(int i=0; i<quantAlunos; i++){
		System.out.printf("%.2f ", notasAlunos[i]);
	}
	System.out.println();
	System.out.println("A média das notas é "+media);

}

}
