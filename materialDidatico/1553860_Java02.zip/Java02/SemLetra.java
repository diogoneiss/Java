import java.util.Scanner;

public class SemLetra{

public static void main(String[] args){
	Scanner leitor = new Scanner(System.in);
	String frase = leitor.nextLine();
	char eliminar = 'a';
	String aux="";
	
	for(int i=0; i<frase.length(); i++){
		if(frase.charAt(i)!=eliminar)
		   aux+=frase.charAt(i);
	}
	
	System.out.println(aux);	
}

}
